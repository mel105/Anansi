class ProbabilityFunction(object):
    pass
