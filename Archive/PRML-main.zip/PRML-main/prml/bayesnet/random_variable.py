class RandomVariable(object):
    """
    Base class for random variable
    """
